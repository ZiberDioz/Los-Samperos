v0.0.1 BETA
---------------------------------------------------
* Reparados todos los bugs encontrados
* [BETA] Sistema AntiAFK
* [BETA] Sistema de Primera Persona
* [BETA] Sistema de Graffitis
* [BETA] Sistema de Municiones
* [BETA] Sistema de Objetos (/recoger y /tirar)
* [BETA] Sistema de Muebles
* Nuevos maps por toda la ciudad
* Nuevas animaciones (/acciones)
* Nueva forma de entrada a interiores (Letra H)
* MOTDs quitados

v0.0.2 BETA
--------------------------------------------------
* Nuevo sistema de tirado de objetos (/tirar)(/recoger)	[BETA]
* Nueva animaci�n al morir.
* Solucionados BUG's del sistema de objetos.
* Solucionados BUG's en el sistema de robo al banco.
* Para comprar en negocios, ahora se usa la tecla ALT.
* Sistema de entorno (disparos).
* Nuevo sistema de aviso de disturbios a SAPD.
* Nuevos comandos (/cuenta) y (/inventario).
* Nuevo sistema de Auto-Taller.
* Nuevo sistema de Necesidades.			[BETA]
* Nuevo sistema de Ganz�as (/puente).			[BETA]
* Quitado el sistema de Garages.
* Nuevo sistema de Garages para las casas.		[BETA]
* Nuevo velocimetro.

v0.0.3 BETA
-------------------------------------------------
* Solucionados BUG's en el sistema de vehiculos del usuario.
* Ahora el comando /estacionar no respawnea el vehiculo.
* Nuevo sistema de limpieza de objetos tirados y respawn de vehiculos autom�tico.
* Nuevo sistema Anti-DM para los nivel 1.
* Nuevo sistema de patentes de vehiculos.
* Ahora se avisa a SAPD que 24-7 est� siendo robado.
* Nuevo sistema de licencias.
* Modificadas casas y negocios.
* Quitadas facciones Licencieros y Banco Central.
* SAEM movido a LS.
* Solucionado BUG en el comando /puente.
* Agregado nuevo JOB de Basurero.
* Arreglado problema con cargado de datos.
* Ahora al desconectarse el jugador, los vehiculos del mismo quedan en el servidor.
* Sistema de vehiculos nuevo realizado totalmente desde 0.
* Ya no es necesario usar el comando /estacionar.
* Removido comando administrativo (/checkllaves) ya que provocaba un bug.
* Solucionado un BUG con los cajeros autom�ticos.
* Agregado un nuevo sistema de venta de autos usados. (/enventa)
* Terminado el sistema de licencias de navegaci�n.
* Sistema de familias removido.
* Renovado y adaptado a las facciones ilegales el sistema de toma de puntos.
* Terminado sistema de robo al banco.
* Agregadas pandillas como facci�nes ileg�les.

v0.0.4
------------------
* Comando /mihq agregado a todas las facciones.
* Comando /ayuda realizado nuevamente.
* Modificada Intro, HUD y Test de rol.
* Garages agregados a las casas.
* Coches en venta agregados.
* Mapeos agregados.
* Agregados iconos en el minimapa para cada auto en venta y cada negocio.
* Eliminados jobs: Vendedor de Moviles, Vendedor de Drogas, Artesano y Bartender.
* Econom�a ajustada.

<!> PROXIMAS VERSIONES:
---------------------------------------------------------
v0.0.5
-----------------
* Arreglado un bug en el login.
* Arreglado un bug con el streamer de objetos.
* Arreglado un bug con el sistema de necesidades.
* Agregado sistema de equipo de sonido para vehiculos.
* Agregado sistema de licencia de armas mediante una prueba pr�ctica.
* Agregado nuevo sistema de casas.
* Agregado nuevo Anticheat.
* PROX: Nuevo sistema administrativo con panel administrativo desde 0.
* PROX: Nuevo sistema de casas desde 0.

v0.1
-----------------
* PROX: Sistema de conquista para pandillas por GangZone.
* PROX: Faccion SAFD.
* PROX: Agregar mas hobbys. (basquet, carreras, pool, etc.)
* PROX: Candado para sapd.
* PROX: Autos y armas por pedido.
* PROX: Job Transportista.
* PROX: Sistema de Celular clickeable.